<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traffic";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if data is received
if (isset($_GET['data'])) {
    // Decode the JSON data received
    $data =  $_GET['data'];
    $user_id = (int)$_GET['user_id'];
    echo $data;
    $data = substr($data, 1, -1);

    $uniqueData = [];
    $pairs = explode(", ", $data);

    foreach ($pairs as $pair) {
        // Split each item into question and answer
        list($question, $answer) = explode("=", $pair, 2);

        // Check if the question doesn't exist in the unique data array
        if (!array_key_exists($question, $uniqueData)) {
            // Add the question to the unique data array
            $uniqueData[$question] = $answer;
        }
    }

    foreach ($uniqueData as $question => $answer) {
        echo $question . "=" . $answer . "<br>";
    }

    $stmt = $conn->prepare("INSERT INTO level2 (question, correct_ans, user_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $question, $correct_ans, $user_id);

    // Insert each question-answer pair into the database
    foreach ($uniqueData as $question => $correct_ans) {
        $question = trim($question);
        $correct_ans = trim($correct_ans);
        $user_id = trim($user_id);

        $stmt->execute();
    }

    if ($stmt->affected_rows > 0) {
        echo "Data inserted successfully.";
    } else {
        echo "Failed to insert data.";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    // If data is not received, echo an error message
    echo "No data received";
}

?>
