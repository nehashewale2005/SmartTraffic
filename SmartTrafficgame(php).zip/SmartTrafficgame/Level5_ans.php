<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traffic";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET['data'])) {
    // Decode the JSON data received
    $data =  $_GET['data'];
    $user_id=(int)$_GET['user_id'];
    echo $data;
    $data = substr($data, 1, -1);
    $pairs = explode(", ", $data);
echo"<br>";
    foreach ($pairs as $pair) {
        echo $pair."<br>";
    }
    $stmt = $conn->prepare("INSERT INTO level5 (question, correct_ans,user_id) VALUES (?, ?,?)");
    $stmt->bind_param("ssi", $question, $correct_ans,$user_id);
    
    foreach ($pairs as $pair) {
        // Split each pair into question and correct answer
        $pairArray = explode("=", $pair);
        $question = trim($pairArray[0]);
        $correct_ans = trim($pairArray[1]);
        $user_id=trim($user_id);
        // Execute the SQL statement
        $stmt->execute();
    }
    if ($stmt->affected_rows > 0) {
        echo "Data inserted successfully.";
    } else {
        echo "Failed to insert data.";
    }
    
    // Close statement and connection
    $stmt->close();
    $conn->close();
       
    } else {
        // If data is not received, echo an error message
        echo "No data received";
    }
?>