<?php

include 'datasource.php';

$sql = "SELECT * FROM `fire`";
$result = $tiffin->query($sql);

if ($result->num_rows > 0) {
   
    while ($row = $result->fetch_assoc()) {
        echo $row["question_id"]. "<br>";
        echo $row["question"]. "<br>";
        echo $row["option_a"]. "<br>";
        echo $row["option_b"]. "<br>";
        echo $row["option_c"]. "<br>";
        echo $row["option_d"]. "<br>";
        echo $row["correct_ans"]. "<br>";
        echo "#";
    }
} else {
    echo "0 results";
}

$tiffin->close();
?>


