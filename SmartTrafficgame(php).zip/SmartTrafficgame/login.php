<?php

include 'datasource.php';
$username=$_GET['username'];
$Password=$_GET['Password'];

$sql="SELECT * FROM `register` WHERE `username`='$username' and `Password`='$Password'";

$result=$tiffin->query($sql);

if($result->num_rows > 0){
    while ($row = $result->fetch_assoc()) {
        echo $row["id"] . "<br>";
    }

    
}else{
  echo "0";
}
?>