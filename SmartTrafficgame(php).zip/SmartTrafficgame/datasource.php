
<?php

$servername="localhost";
$username="root";
$password="";
$dbname="traffic";

$tiffin = new mysqli($servername, $username, $password, $dbname );
if(!$tiffin)
{
    trigger_error('Could not connect to mysql:' .mysqli_connect_error());
}
 else
     {
    // echo 'connect';  echo 'connect';
     return $tiffin;
    // echo 'connect';
 }

        


?>

