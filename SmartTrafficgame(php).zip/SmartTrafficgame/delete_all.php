<?php

include 'datasource.php';
$user=$_GET['user_id'];

$sql="DELETE FROM `level1` WHERE  `user_id`='$user'";

$result=$tiffin->query($sql);

$sql1="DELETE FROM `level2` WHERE  `user_id`='$user'";

$result1=$tiffin->query($sql1);

$sql2="DELETE FROM `level3` WHERE  `user_id`='$user'";

$result2=$tiffin->query($sql2);

$sql3="DELETE FROM `level4` WHERE  `user_id`='$user'";

$result3=$tiffin->query($sql3);

$sql4="DELETE FROM `level5` WHERE  `user_id`='$user'";

$result4=$tiffin->query($sql4);

if($result){
  echo "1";
    
}else{
  echo "0";
}

