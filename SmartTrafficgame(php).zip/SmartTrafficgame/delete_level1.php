<?php

include 'datasource.php';
$user=$_GET['user_id'];

$sql="DELETE FROM `level1` WHERE  `user_id`='$user'";
$result=$tiffin->query($sql);


if($result){
    echo "1";
      
  }else{
    echo "0";
  }