<?php

include 'datasource.php';
$user=$_GET['user_id'];

$sql1="DELETE FROM `level5` WHERE  `user_id`='$user'";

$result1=$tiffin->query($sql1);

if($result1){
    echo "1";
      
  }else{
    echo "0";
  }
  ?>