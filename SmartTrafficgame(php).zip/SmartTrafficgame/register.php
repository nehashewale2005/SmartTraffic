<?php

include 'datasource.php';

// Check if all required parameters are set
if(isset($_GET['username'], $_GET['Email'], $_GET['Password'], $_GET['MobileNo'], $_GET['Address'])) {
    // Retrieve parameters
    $username = $_GET['username'];
    $Email = $_GET['Email'];
    $Password = $_GET['Password'];
    $MobileNo = $_GET['MobileNo'];
    $Address = $_GET['Address'];

    // Prepare SQL query
    $sql = "INSERT INTO `register`(`username`, `Email`, `Password`, `MobileNo`, `Address`) VALUES ('$username','$Email','$Password','$MobileNo','$Address')";

    // Execute query
    $res = $tiffin->query($sql);
    if($res === TRUE){
        echo "1";
    } else {
        echo "0";
    }

}
?>