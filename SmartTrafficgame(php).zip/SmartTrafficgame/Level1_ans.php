<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traffic";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if data is received
if(isset($_GET['data'])) {
    // Decode the JSON data received
    $data =  $_GET['data'];
    $user_id=(int)$_GET['user_id'];
    echo $data;
    $data = substr($data, 1, -1);
    $pairs = explode(", ", $data);

    foreach ($pairs as $pair) {
        echo $pair."<br>";
    }
   

    $stmt = $conn->prepare("INSERT INTO level1 (question, correct_ans,user_id) VALUES (?, ?,?)");
$stmt->bind_param("ssi", $question, $correct_ans,$user_id);

// Insert each question-answer pair into the database
foreach ($pairs as $pair) {
    // Split each pair into question and correct answer
    $pairArray = explode("=", $pair);
    $question = trim($pairArray[0]);
    $correct_ans = trim($pairArray[1]);
    $user_id=trim($user_id);
    // Execute the SQL statement
    $stmt->execute();
}
if ($stmt->affected_rows > 0) {
    echo "Data inserted successfully.";
} else {
    echo "Failed to insert data.";
}

// Close statement and connection
$stmt->close();
$conn->close();
    // Prepare and bind SQL statement
    // $stmt = $conn->prepare("INSERT INTO level1 (question, correct_ans) VALUES (?, ?)");
    // $stmt->bind_param("ss", $question, $selected_option);

    // // Insert each question-answer pair into the database
    // foreach ($data as $question => $selected_option) {
    //     // Execute the SQL statement
    //     $stmt->execute();
    // }

    // // Check if insertion was successful
    // if ($stmt->affected_rows > 0) {
    //     echo "1"; // Success
    // } else {
    //     echo "0"; // Failure
    // }
} else {
    // If data is not received, echo an error message
    echo "No data received";
}

// Close statement and connection

?>
