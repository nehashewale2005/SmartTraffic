<?php

include 'datasource.php';
$username=$_GET['id'];
 

$sql="SELECT * FROM `register` WHERE `id`='$username' ";

$result=$tiffin->query($sql);

if($result->num_rows > 0){
    while ($row = $result->fetch_assoc()) {
        echo $row["username"] . "<br>";
        echo date('d-m-Y')."<br>";
        echo "#";
    } 
}else{
  echo "0";
}
?>