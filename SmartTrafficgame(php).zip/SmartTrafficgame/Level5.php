<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traffic";


$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$user=$_GET['user_id'];
$sql ="SELECT 
(SELECT COUNT(*) FROM level5 where user_id='$user') AS answer_count, 
(SELECT COUNT(*) 
 FROM level5 l5 
 JOIN fire t ON l5.question = t.question
 WHERE user_id='$user' and  l5.correct_ans = t.correct_ans) AS correct_answers_count";


$result = $conn->query($sql);

$response = array();

if ($result->num_rows > 0) {
    
    $row = $result->fetch_assoc();

    echo $row['answer_count']."<br>";
   echo $row['correct_answers_count'];
   echo "#";
} else {
   
    $response['error'] = "No results found";
}


header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
